"""
IFRS 17 Stochastic Reserving Engine — Real Data Calibration
============================================================
Uses real district-level dengue surveillance data from Vietnam
(Gibb et al. 2023, Nature Communications) for 4 provinces,
1998–2021.

Source:
  github.com/rorygibb/dengue_vietnam_ms
  Gibb R et al. "Interactions between climate change, urban
  infrastructure and mobility are driving dengue emergence
  in Vietnam." Nat Commun 14, 8179 (2023).

Pipeline:
  1. Ingest & aggregate district → province → annual
  2. Fit log-normal marginals to each province
  3. Calibrate Gumbel copula via Kendall's tau
  4. Monte Carlo 100k simulations
  5. Compute IFRS 17 Risk Adjustment (TVaR/CTE)
  6. Diagnostic plots + sensitivity analysis
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import lognorm, kendalltau, probplot
from statsmodels.distributions.copula.api import GumbelCopula

# ── Reproducibility ──────────────────────────────────────────────────
SEED = 42
rng = np.random.default_rng(SEED)
np.random.seed(SEED)

# =====================================================================
# PHASE 1 — DATA INGESTION & CALIBRATION
# =====================================================================
print("=" * 65)
print("PHASE 1: DATA INGESTION & CALIBRATION (Real Data)")
print("=" * 65)

# ── 1a. Load & aggregate ────────────────────────────────────────────
from pathlib import Path
raw = pd.read_csv(Path(__file__).parent / "dengue_districts_19982020.csv")
print(f"Loaded {len(raw):,} district-month records")
print(f"Provinces: {', '.join(raw['province'].unique())}")
print(f"Period: {raw['year'].min()}–{raw['year'].max()}")

# Aggregate: district-month → province-year
annual = raw.groupby(["province", "year"])["cases"].sum().reset_index()
pivot = annual.pivot(index="year", columns="province", values="cases")

# ── 1b. Select region pair ──────────────────────────────────────────
# Dong Nai (southeast) & Khanh Hoa (south-central coast):
#   - Both southern, dengue-endemic
#   - Strong upper-tail dependence (simultaneous outbreaks)
#   - 2019 mega-spike visible in both
#
# Drop early years with zeros (incomplete surveillance rollout)
REGION_A = "Dong Nai"
REGION_B = "Khanh Hoa"

pair = pivot[[REGION_A, REGION_B]].dropna()
pair = pair[(pair[REGION_A] > 0) & (pair[REGION_B] > 0)]
print(f"\nUsing: {REGION_A} vs {REGION_B}")
print(f"Usable years: {len(pair)} ({pair.index.min()}–{pair.index.max()})")
print(pair.to_string())

# ── 1c. Fit marginals (log-normal) ──────────────────────────────────
shape_a, _, scale_a = lognorm.fit(pair[REGION_A], floc=0)
shape_b, _, scale_b = lognorm.fit(pair[REGION_B], floc=0)

mu_a, mu_b = np.log(scale_a), np.log(scale_b)
print(f"\nCalibrated {REGION_A} Log-Normal:  sigma = {shape_a:.4f},  mu = {mu_a:.4f}")
print(f"Calibrated {REGION_B} Log-Normal:  sigma = {shape_b:.4f},  mu = {mu_b:.4f}")

# ── 1d. Calibrate copula (Gumbel) ───────────────────────────────────
tau, p_value = kendalltau(pair[REGION_A], pair[REGION_B])
theta_calibrated = 1.0 / (1.0 - tau)

print(f"\nKendall tau  = {tau:.4f}  (p = {p_value:.4f})")
print(f"Gumbel theta = {theta_calibrated:.4f}")

if theta_calibrated < 1.0:
    print("Warning: theta < 1 — clamping to 1.01 (independence)")
    theta_calibrated = 1.01

# =====================================================================
# PHASE 2 — MONTE CARLO SIMULATION
# =====================================================================
N_SIM = 100_000
print(f"\n{'=' * 65}")
print(f"PHASE 2: MONTE CARLO SIMULATION  (n = {N_SIM:,})")
print("=" * 65)

# ── 2a. Copula-linked draws ─────────────────────────────────────────
gumbel = GumbelCopula(theta=theta_calibrated)
copula_u = gumbel.rvs(N_SIM, random_state=SEED)

claims_a_cop = lognorm.ppf(copula_u[:, 0], s=shape_a, scale=scale_a)
claims_b_cop = lognorm.ppf(copula_u[:, 1], s=shape_b, scale=scale_b)
total_cop = claims_a_cop + claims_b_cop

# ── 2b. Independent baseline (same marginals, shuffled pairing) ─────
u1 = copula_u[:, 0].copy()
u2 = copula_u[:, 1].copy()
rng.shuffle(u2)

claims_a_ind = lognorm.ppf(u1, s=shape_a, scale=scale_a)
claims_b_ind = lognorm.ppf(u2, s=shape_b, scale=scale_b)
total_ind = claims_a_ind + claims_b_ind

# =====================================================================
# PHASE 3 — IFRS 17 RISK ADJUSTMENT (TVaR / CTE)
# =====================================================================
print(f"\n{'=' * 65}")
print("PHASE 3: IFRS 17 RISK ADJUSTMENT")
print("=" * 65)


def ifrs17_metrics(claims: np.ndarray, alpha: float = 0.99):
    """
    BEL  = E[X]
    VaR  = F^{-1}(alpha)
    TVaR = E[X | X >= VaR]   (conditional tail expectation)
    RA   = TVaR - BEL
    """
    bel = np.mean(claims)
    var = np.percentile(claims, alpha * 100)
    tvar = np.mean(claims[claims >= var])
    ra = tvar - bel
    return {"BEL": bel, "VaR_99": var, "TVaR_99": tvar, "RA": ra}


met_cop = ifrs17_metrics(total_cop)
met_ind = ifrs17_metrics(total_ind)

row_fmt = "{:<28s}{:>14,.0f}{:>14,.0f}"
print(f"\n{'Metric':<28s}{'Independent':>14s}{'Gumbel Copula':>14s}")
print("-" * 56)
for k in ["BEL", "VaR_99", "TVaR_99", "RA"]:
    print(row_fmt.format(k, met_ind[k], met_cop[k]))

underest = (met_cop["RA"] / met_ind["RA"] - 1) * 100
print(f"\n-> Capital underestimation if dependence ignored: {underest:+.1f}%")
print(f"   (Risk Adjustment: {met_ind['RA']:,.0f} -> {met_cop['RA']:,.0f} cases)")

# =====================================================================
# PHASE 4 — DIAGNOSTIC PLOTS
# =====================================================================
fig, axes = plt.subplots(2, 3, figsize=(18, 11))
fig.suptitle(
    "IFRS 17 Stochastic Reserving Engine — Vietnam Dengue (Real Data)",
    fontsize=15, fontweight="bold", y=0.97,
)

# ── 4a. Historical time series ───────────────────────────────────────
ax = axes[0, 0]
ax.plot(pair.index, pair[REGION_A], "o-", color="#185FA5",
        label=REGION_A, linewidth=1.5)
ax.plot(pair.index, pair[REGION_B], "s-", color="#993C1D",
        label=REGION_B, linewidth=1.5)
ax.set_xlabel("Year")
ax.set_ylabel("Annual dengue cases")
ax.set_title(f"Historical data — {REGION_A} vs {REGION_B}")
ax.legend(fontsize=9)
ax.grid(alpha=0.3)

# ── 4b. QQ plot: fitted log-normal vs historical ────────────────────
ax = axes[0, 1]
probplot(pair[REGION_A], dist=lognorm,
         sparams=(shape_a, 0, scale_a), plot=ax)
ax.set_title(f"QQ plot — {REGION_A} vs fitted log-normal")
ax.get_lines()[0].set(marker="o", color="#185FA5", markersize=5)
ax.get_lines()[1].set(color="#993C1D", linewidth=1.2)

# ── 4c. Scatter: copula vs independent ──────────────────────────────
ax = axes[0, 2]
n_show = 5000
ax.scatter(claims_a_ind[:n_show], claims_b_ind[:n_show],
           s=4, alpha=0.2, color="#888780", label="Independent")
ax.scatter(claims_a_cop[:n_show], claims_b_cop[:n_show],
           s=4, alpha=0.2, color="#185FA5", label="Gumbel copula")
ax.scatter(pair[REGION_A], pair[REGION_B],
           s=60, color="#993C1D", edgecolors="white",
           zorder=5, label="Historical")
ax.set_xlabel(f"{REGION_A} cases")
ax.set_ylabel(f"{REGION_B} cases")
ax.set_title("Joint scatter — copula vs independent")
ax.legend(fontsize=9, markerscale=2)

# ── 4d. Tail density comparison ─────────────────────────────────────
ax = axes[1, 0]
p95_cop = np.percentile(total_cop, 95)
bins = np.linspace(p95_cop, np.percentile(total_cop, 99.9), 80)
ax.hist(total_ind, bins=bins, density=True, alpha=0.5,
        color="#888780", label="Independent tail")
ax.hist(total_cop, bins=bins, density=True, alpha=0.5,
        color="#185FA5", label="Copula tail")
ax.axvline(met_cop["VaR_99"], color="#993C1D", ls="--",
           lw=1.2, label="VaR 99%")
ax.axvline(met_cop["TVaR_99"], color="#D85A30", ls="-",
           lw=1.5, label="TVaR 99%")
ax.set_xlabel("Total cases (both provinces)")
ax.set_title("Tail density (above 95th percentile)")
ax.legend(fontsize=8)

# ── 4e. Sensitivity: RA vs theta ────────────────────────────────────
ax = axes[1, 1]
theta_range = np.linspace(1.01, max(3.5, theta_calibrated + 1.5), 30)
ra_values = []
for th in theta_range:
    g = GumbelCopula(theta=th)
    u = g.rvs(N_SIM, random_state=SEED)
    sim = (lognorm.ppf(u[:, 0], s=shape_a, scale=scale_a) +
           lognorm.ppf(u[:, 1], s=shape_b, scale=scale_b))
    ra_values.append(ifrs17_metrics(sim)["RA"])

ax.plot(theta_range, ra_values, color="#185FA5", linewidth=2)
ax.axvline(theta_calibrated, color="#993C1D", ls="--", lw=1.2,
           label=f"Calibrated theta = {theta_calibrated:.2f}")
ax.set_xlabel("Gumbel theta")
ax.set_ylabel("Risk Adjustment (cases)")
ax.set_title("Sensitivity — RA vs copula strength")
ax.legend(fontsize=9)
ax.grid(alpha=0.3)

# ── 4f. All four provinces historical ────────────────────────────────
ax = axes[1, 2]
colors_map = {"Ha Noi": "#185FA5", "Dong Nai": "#993C1D",
              "Khanh Hoa": "#0F6E56", "Dak Lak": "#854F0B"}
for prov in pivot.columns:
    ax.plot(pivot.index, pivot[prov], "o-",
            color=colors_map.get(prov, "gray"),
            label=prov, linewidth=1.2, markersize=3)
ax.set_xlabel("Year")
ax.set_ylabel("Annual dengue cases")
ax.set_title("All 4 provinces — historical trends")
ax.legend(fontsize=8)
ax.grid(alpha=0.3)

plt.tight_layout(rect=[0, 0, 1, 0.94])
plt.savefig("ifrs17_diagnostics.png", dpi=180, bbox_inches="tight")
plt.show()
print("\n-> Diagnostic plots saved to ifrs17_diagnostics.png")

# =====================================================================
# PHASE 5 — SUMMARY TABLE
# =====================================================================
summary = pd.DataFrame({
    "Model": ["Independent", "Gumbel Copula"],
    "BEL": [met_ind["BEL"], met_cop["BEL"]],
    "VaR_99": [met_ind["VaR_99"], met_cop["VaR_99"]],
    "TVaR_99": [met_ind["TVaR_99"], met_cop["TVaR_99"]],
    "Risk_Adjustment": [met_ind["RA"], met_cop["RA"]],
}).round(0)

print(f"\n{'=' * 65}")
print("SUMMARY")
print("=" * 65)
print(summary.to_string(index=False))
print(f"\nCapital underestimation: {underest:+.1f}%")
print(f"\nData source: Gibb et al. (2023) Nature Communications")
print(f"Regions: {REGION_A} & {REGION_B}, {len(pair)} years")
print(f"Calibrated Gumbel theta = {theta_calibrated:.3f} (tau = {tau:.3f})")
