"""
In terminal, run with: python -m streamlit run app.py. Make sure to have the required CSV files in the specified paths.
"""

import numpy as np
import matplotlib.pyplot as plt
import streamlit as st
from scipy.linalg import expm, eigvals
from sklearn.linear_model import LinearRegression
import pandas as pd

# COMPUTATION FUNCTIONS

def load_mortality_data(filepath, age_min=30, age_max=90, year=2023):
    df = pd.read_csv(filepath)
    df = df[df["Year"] == year]
    ages = df["Age (x)"].values.astype(float)
    mx = df["Central death rate m(x,n)"].values.astype(float)
    mask = (ages >= age_min) & (ages <= age_max)
    ages = ages[mask]
    mx = mx[mask]
    return ages, mx, np.ones_like(mx)


def fit_gompertz(ages, Dx, Ex):
    lambda_hat = np.clip(Dx / Ex, 1e-10, None)
    y = np.log(lambda_hat)

    # Build the design matrix X = [1, age]
    n = len(ages)
    X = np.column_stack([np.ones(n), ages])

    # Normal equations: beta = (X^T X)^{-1} X^T y
    XtX = X.T @ X
    Xty = X.T @ y
    beta = np.linalg.solve(XtX, Xty)

    A = np.exp(beta[0])
    B = beta[1]

    return A, B, lambda_hat


def gompertz_hazard(age, A, B):
    return A * np.exp(B * age)


def build_generator(age, A, B, lambda_HD, lambda_DH, DD_factor):
    mu_H = gompertz_hazard(age, A, B)
    mu_D = DD_factor * mu_H
    Q = np.array([
        [-(lambda_HD + mu_H),   lambda_HD,            mu_H  ],
        [  lambda_DH,          -(lambda_DH + mu_D),   mu_D  ],
        [  0,                    0,                    0     ]
    ])
    return Q


def evolve_probabilities(age_start, A, B, params, T=50, dt=0.1):
    n_steps = int(T / dt)
    times = np.arange(n_steps) * dt
    trajectory = np.zeros((n_steps, 3))
    state = np.array([1.0, 0.0, 0.0])
    for i, t in enumerate(times):
        trajectory[i] = state
        age = age_start + t
        Q = build_generator(age, A, B, **params)
        P_mat = expm(Q * dt)
        state = state @ P_mat
    return times, trajectory


def compute_EPV(age_start, A, B, params, r=0.03, benefit=100_000,
                T=50, dt=0.1):
    state = np.array([1.0, 0.0, 0.0])
    EPV = 0.0
    for t in np.arange(0, T, dt):
        age = age_start + t
        Q = build_generator(age, A, B, **params)
        P_mat = expm(Q * dt)
        next_state = state @ P_mat
        death_increment = next_state[2] - state[2]
        discount = np.exp(-r * t)
        EPV += benefit * death_increment * discount
        state = next_state
    return EPV

# APP CONFIG

st.set_page_config(
    page_title="Life Insurance Valuation",
    page_icon="🛡️",
    layout="wide"
)

# SIDEBAR: MODE TOGGLE + INPUTS

mode = st.sidebar.radio(
    "Mode",
    ["Simple", "Advanced"],
    index=0,
    help="Simple: answer a few personal questions. "
         "Advanced: full control over model parameters."
)

st.sidebar.divider()

# --- SIMPLE MODE INPUTS ---
if mode == "Simple":

    st.sidebar.header("About You")

    age_start = st.sidebar.slider(
        "How old are you?",
        min_value=30,
        max_value=70,
        value=40,
        step=1
    )

    sex = st.sidebar.radio(
        "Sex",
        ["Male", "Female"],
        index=0
    )

    health = st.sidebar.radio(
        "Do you have a chronic health condition?",
        ["No", "Mild (e.g., managed diabetes, mild asthma)",
         "Significant (e.g., heart disease, COPD)"],
        index=0
    )

    st.sidebar.divider()
    st.sidebar.header("Coverage")

    benefit = st.sidebar.select_slider(
        "How much life insurance coverage?",
        options=[50_000, 100_000, 250_000, 500_000, 1_000_000],
        value=100_000,
        format_func=lambda x: f"${x:,}"
    )

    # Map user-friendly inputs to model parameters
    dataset_map = {
    "Male": r"C:\Users\KIETLINH\Downloads\Gompertz-calibrated Markov insurance liability valuation\mortality_data_male.csv",
    "Female": r"C:\Users\KIETLINH\Downloads\Gompertz-calibrated Markov insurance liability valuation\mortality_data_female.csv"
    }
    filepath = dataset_map[sex]

    health_map = {
        "No": 0.01,
        "Mild (e.g., managed diabetes, mild asthma)": 0.03,
        "Significant (e.g., heart disease, COPD)": 0.06,
    }
    lambda_HD = health_map[health]

    # Fixed parameters the user doesn't see
    lambda_DH = 0.10
    DD_factor = 2.0
    discount_rate = 0.03

# --- ADVANCED MODE INPUTS ---
else:

    st.sidebar.header("Data")

    dataset = st.sidebar.selectbox(
        "Mortality Dataset",
        ["Both Sexes", "Male", "Female"],
        index=0
    )
    dataset_map = {
    "Both Sexes": r"C:\Users\KIETLINH\Downloads\Gompertz-calibrated Markov insurance liability valuation\mortality_data.csv",
    "Male": r"C:\Users\KIETLINH\Downloads\Gompertz-calibrated Markov insurance liability valuation\mortality_data_male.csv",
    "Female": r"C:\Users\KIETLINH\Downloads\Gompertz-calibrated Markov insurance liability valuation\mortality_data_female.csv"
    }
    filepath = dataset_map[dataset]

    age_start = st.sidebar.slider(
        "Starting Age",
        min_value=30, max_value=70, value=40, step=5
    )

    st.sidebar.subheader("Disability Parameters")

    lambda_HD = st.sidebar.slider(
        "λ_HD (Healthy → Disabled)",
        min_value=0.005, max_value=0.15, value=0.02,
        step=0.005, format="%.3f"
    )
    lambda_DH = st.sidebar.slider(
        "λ_DH (Disabled → Healthy)",
        min_value=0.01, max_value=0.20, value=0.10,
        step=0.01, format="%.2f"
    )
    DD_factor = st.sidebar.slider(
        "Disabled Mortality Multiplier",
        min_value=1.0, max_value=4.0, value=2.0,
        step=0.1, format="%.1f"
    )

    st.sidebar.subheader("Financial Parameters")

    discount_rate = st.sidebar.slider(
        "Discount Rate (r)",
        min_value=0.01, max_value=0.08, value=0.03,
        step=0.005, format="%.3f"
    )
    benefit = st.sidebar.number_input(
        "Death Benefit ($)",
        min_value=10000, max_value=1000000, value=100000, step=10000
    )

# RUN MODEL 

ages, Dx, Ex = load_mortality_data(filepath)
A, B, lambda_hat = fit_gompertz(ages, Dx, Ex)

params = {
    "lambda_HD": lambda_HD,
    "lambda_DH": lambda_DH,
    "DD_factor": DD_factor,
}

T_sim = 90 - age_start
times, traj = evolve_probabilities(age_start, A, B, params, T=T_sim)
epv = compute_EPV(age_start, A, B, params, r=discount_rate,
                  benefit=benefit, T=T_sim)

# SIMPLE MODE DISPLAY

if mode == "Simple":

    st.title("🛡️ Life Insurance Estimator")
    st.markdown("See how much an insurer would need to set aside "
                "to cover your policy, based on Vietnamese mortality data.")

    # --- Hero metric ---
    st.divider()

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("Your Age", f"{age_start}")
    with col2:
        st.metric("Coverage", f"${benefit:,}")
    with col3:
        st.metric(
            "Estimated Reserve",
            f"${epv:,.0f}",
            help="This is the Expected Present Value (EPV) — the amount "
                 "an insurer would set aside today to cover your policy."
        )

    st.divider()

    # --- Plain-language explanation ---
    pct = epv / benefit * 100
    st.markdown(
        f"Based on current Vietnamese mortality data, an insurer would need "
        f"to reserve **\\${epv:,.0f}** today to guarantee your "
        f"**\\${benefit:,}** death benefit. That's about **{pct:.0f}%** of "
        f"the coverage amount — the rest is earned through investment "
        f"returns over time."
    )

    if health != "No":
        st.info(
            f"Because you indicated a health condition, the model assumes "
            f"a higher rate of disability (λ = {lambda_HD}), which increases "
            f"the reserve by exposing you to elevated mortality risk."
        )

    # --- State evolution plot ---
    st.subheader("Your Projected Health Trajectory")

    fig, ax = plt.subplots(figsize=(10, 5))

    ax.fill_between(times + age_start, 0, traj[:, 2],
                    alpha=0.3, color="#e74c3c", label="Deceased")
    ax.fill_between(times + age_start, traj[:, 2], traj[:, 2] + traj[:, 1],
                    alpha=0.3, color="#e67e22", label="Disabled")
    ax.fill_between(times + age_start, traj[:, 2] + traj[:, 1], 1,
                    alpha=0.3, color="#2ecc71", label="Healthy")

    ax.plot(times + age_start, 1 - traj[:, 2], color="#2ecc71", linewidth=2)
    ax.plot(times + age_start, traj[:, 2] + traj[:, 1],
            color="#e67e22", linewidth=1, linestyle="--")
    ax.plot(times + age_start, traj[:, 2], color="#e74c3c", linewidth=2)

    ax.set_xlabel("Age", fontsize=12)
    ax.set_ylabel("Probability", fontsize=12)
    ax.set_title("Probability of being in each state over time", fontsize=14)
    ax.legend(loc="center right", fontsize=11)
    ax.set_xlim(age_start, 90)
    ax.set_ylim(0, 1)
    ax.grid(True, alpha=0.2)

    plt.tight_layout()
    st.pyplot(fig)
    plt.close()

    st.caption(
        "This chart shows the probability of being healthy, disabled, "
        "or deceased at each age, based on a continuous-time Markov model "
        "calibrated to Vietnamese mortality data (UN WPP 2023)."
    )

    # --- Compare with other sex ---
    st.subheader("How does sex affect the reserve?")

    other_sex = "Female" if sex == "Male" else "Male"
    other_filepath = dataset_map[other_sex]
    other_ages, other_Dx, other_Ex = load_mortality_data(other_filepath)
    other_A, other_B, _ = fit_gompertz(other_ages, other_Dx, other_Ex)
    other_epv = compute_EPV(age_start, other_A, other_B, params,
                            r=discount_rate, benefit=benefit, T=T_sim)

    col_a, col_b = st.columns(2)
    with col_a:
        st.metric(f"{sex}", f"${epv:,.0f}")
    with col_b:
        diff = other_epv - epv
        st.metric(f"{other_sex}", f"${other_epv:,.0f}",
                  delta=f"${diff:+,.0f}", delta_color="inverse")

    if sex == "Male":
        st.markdown(
            "Men typically require a higher reserve because male mortality "
            "rates are higher at every age, meaning the benefit is expected "
            "to be paid sooner."
        )
    else:
        st.markdown(
            "Women typically require a lower reserve because female mortality "
            "rates are lower, meaning the benefit payment is expected later "
            "and gets discounted more."
        )

    # --- Age comparison ---
    st.subheader("How does age affect the reserve?")

    test_ages = [30, 35, 40, 45, 50, 55, 60, 65, 70]
    age_epvs = []
    for a in test_ages:
        t_sim = 90 - a
        if t_sim > 0:
            e = compute_EPV(a, A, B, params, r=discount_rate,
                            benefit=benefit, T=t_sim)
            age_epvs.append(e)
        else:
            age_epvs.append(0)

    fig, ax = plt.subplots(figsize=(10, 4))
    bars = ax.bar(test_ages, age_epvs, width=3, color="#3498db", alpha=0.8)

    # Highlight user's age
    closest_age = min(test_ages, key=lambda x: abs(x - age_start))
    for bar, a in zip(bars, test_ages):
        if a == closest_age:
            bar.set_color("#e74c3c")
            bar.set_alpha(1.0)

    ax.set_xlabel("Starting Age", fontsize=12)
    ax.set_ylabel("Reserve Required ($)", fontsize=12)
    ax.set_title(f"Reserve for ${benefit:,} policy by starting age",
                 fontsize=14)
    ax.grid(True, alpha=0.2, axis="y")

    plt.tight_layout()
    st.pyplot(fig)
    plt.close()

    st.caption(
        "Older individuals require higher reserves because they are "
        "closer to the expected payout date, so there's less time "
        "for investment returns to grow."
    )
# --- Disability comparison ---
    st.subheader("How does health status affect the reserve?")

    health_labels = ["No condition", "Mild condition", "Significant condition"]
    health_rates = [0.01, 0.03, 0.06]
    health_epvs = []

    for rate in health_rates:
        health_params = {**params, "lambda_HD": rate}
        e = compute_EPV(age_start, A, B, health_params,
                        r=discount_rate, benefit=benefit, T=T_sim)
        health_epvs.append(e)

    fig, ax = plt.subplots(figsize=(10, 4))
    bars = ax.bar(health_labels, health_epvs, width=0.5,
                  color=["#2ecc71", "#e67e22", "#e74c3c"], alpha=0.8)

    for bar, val in zip(bars, health_epvs):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 200,
                f"\\${val:,.0f}", ha="center", fontsize=12, fontweight="bold")

    ax.set_ylabel("Reserve Required ($)", fontsize=12)
    ax.set_title(f"Reserve for \\${benefit:,} policy by health status "
                 f"(age {age_start}, {sex})", fontsize=14)
    ax.grid(True, alpha=0.2, axis="y")

    plt.tight_layout()
    st.pyplot(fig)
    plt.close()

    st.caption(
        "A chronic health condition increases the rate of transitioning "
        "to a higher-mortality state (disabled), which leads to earlier "
        "expected payouts and a higher reserve. The disability inception "
        "rates used are: No condition (λ = 0.01), Mild (λ = 0.03), "
        "Significant (λ = 0.06)."
    )
    # --- Footer ---
    st.divider()
    with st.expander("About this model"):
        st.markdown(
            """
            This tool uses a **continuous-time Markov chain** with three 
            states (Healthy, Disabled, Dead) to model insurance liabilities.

            - **Mortality** is calibrated using the Gompertz law fitted to 
              Vietnamese data from the UN World Population Prospects (2023).
            - **Disability parameters** are assumed from actuarial literature, 
              not calibrated from Vietnamese-specific data.
            - **The reserve** (Expected Present Value) is the amount an insurer 
              would need to invest today at a 3% annual return to cover the 
              future death benefit payment.

            Built as a Linear Algebra course project. The core computation 
            uses matrix exponentials and eigenvalue analysis.

            *Switch to Advanced mode in the sidebar for full parameter control.*
            """
        )

# ADVANCED MODE DISPLAY

else:

    st.title("Continuous-Time Multi-State Actuarial Valuation")
    st.markdown(
        "*Gompertz-Calibrated Mortality with Age-Dependent Markov Models*"
    )

    col_left, col_right = st.columns([2, 1])

    with col_left:
        tab1, tab2, tab3 = st.tabs([
            "📈 Gompertz Fit",
            "📊 State Evolution",
            "🔍 Sensitivity"
        ])

        with tab1:
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
            fitted = gompertz_hazard(ages, A, B)

            ax1.scatter(ages, lambda_hat, s=30, alpha=0.7,
                        label="Observed rates", zorder=5)
            ax1.plot(ages, fitted, "r-", linewidth=2, label="Gompertz fit")
            ax1.set_xlabel("Age")
            ax1.set_ylabel("Force of mortality μ(x)")
            ax1.set_title("Natural Scale")
            ax1.legend()
            ax1.grid(True, alpha=0.3)

            ax2.scatter(ages, np.log(lambda_hat), s=30, alpha=0.7,
                        label="log(observed)", zorder=5)
            ax2.plot(ages, np.log(fitted), "r-", linewidth=2,
                     label="log(Gompertz)")
            ax2.set_xlabel("Age")
            ax2.set_ylabel("log μ(x)")
            ax2.set_title("Log Scale (should be linear)")
            ax2.legend()
            ax2.grid(True, alpha=0.3)

            plt.tight_layout()
            st.pyplot(fig)
            plt.close()

        with tab2:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(times + age_start, traj[:, 0], label="Healthy",
                    linewidth=2, color="#2ecc71")
            ax.plot(times + age_start, traj[:, 1], label="Disabled",
                    linewidth=2, color="#e67e22")
            ax.plot(times + age_start, traj[:, 2], label="Dead",
                    linewidth=2, color="#e74c3c")
            ax.set_xlabel("Age")
            ax.set_ylabel("Probability")
            ax.set_title(
                f"State Probability Evolution (starting age {age_start})"
            )
            ax.legend(fontsize=12)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            st.pyplot(fig)
            plt.close()

        with tab3:
            test_rates = np.linspace(0.005, 0.15, 20)
            test_epvs = []
            for lam in test_rates:
                test_params = {**params, "lambda_HD": lam}
                test_epv = compute_EPV(age_start, A, B, test_params,
                                       r=discount_rate, benefit=benefit,
                                       T=T_sim)
                test_epvs.append(test_epv)

            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(test_rates, test_epvs, "b-o", markersize=4)
            ax.axvline(x=lambda_HD, color="red", linestyle="--", alpha=0.7,
                       label=f"Current λ_HD = {lambda_HD:.3f}")
            ax.axhline(y=epv, color="red", linestyle="--", alpha=0.3)
            ax.set_xlabel("Disability Inception Rate λ_HD")
            ax.set_ylabel("EPV of Death Benefit ($)")
            ax.set_title("Sensitivity: EPV vs. Disability Rate")
            ax.legend()
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            st.pyplot(fig)
            plt.close()

    with col_right:
        st.subheader("Gompertz Parameters")
        st.metric("A (baseline)", f"{A:.8f}")
        st.metric("B (aging rate)", f"{B:.6f}")
        st.metric("Doubling time", f"{np.log(2)/B:.1f} years")

        st.divider()

        st.subheader("Expected Present Value")
        st.metric("EPV", f"${epv:,.2f}")
        st.caption(
            f"Starting age {age_start} · "
            f"${benefit:,} benefit · "
            f"{discount_rate:.1%} discount rate"
        )

        st.divider()

        st.subheader(f"Generator Matrix Q({age_start})")
        Q_display = build_generator(age_start, A, B, **params)
        st.dataframe(
            {
                "": ["Healthy", "Disabled", "Dead"],
                "Healthy": Q_display[:, 0],
                "Disabled": Q_display[:, 1],
                "Dead": Q_display[:, 2],
            },
            hide_index=True,
            width="stretch"
        )

        st.divider()

        st.subheader(f"Eigenvalues at Age {age_start}")
        evals = eigvals(Q_display)
        for ev in sorted(evals, key=lambda x: x.real):
            val = ev.real
            if abs(val) < 1e-10:
                st.success(f"λ = 0  (absorbing state) ✓")
            elif val < 0:
                st.success(f"λ = {val:.6f}  (stable) ✓")
            else:
                st.error(f"λ = {val:.6f}  (unstable) ✗")

        st.divider()

        st.subheader("Probability Check")
        max_dev = np.max(np.abs(traj.sum(axis=1) - 1))
        st.metric("Max deviation from 1", f"{max_dev:.2e}")

    # --- Footer ---
    st.divider()
    st.caption(
        "Data: UN World Population Prospects 2024 revision, "
        "Vietnam 2023 abridged life tables. "
        "Disability parameters assumed from actuarial literature."
    )